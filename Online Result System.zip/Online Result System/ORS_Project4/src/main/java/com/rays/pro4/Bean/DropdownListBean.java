package com.rays.pro4.Bean;

/**
 * DropdownList interface is implemented by Beans those are used to create drop
 * down list on HTML pages.
 * 
 * @author Abhishek Kushwaha
 *
 */

public interface DropdownListBean {

	public String getkey();

	public String getValue();

}
